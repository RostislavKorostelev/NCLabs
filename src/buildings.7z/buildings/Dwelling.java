package buildings;


public class Dwelling
{
	private DwellingFloor floors[];
	
	public Dwelling(int countFloors, DwellingFloor[] floor )
	{
		floors = new DwellingFloor[countFloors];
		for (int i=0; i<countFloors; i++)
		{
			floors[i] = floor[i];
		}	
	}
	
	public Dwelling(DwellingFloor[] floors)
	{
		this.floors = new DwellingFloor[floors.length];
		for	(int i = 0; i< floors.length; i++)
		{
			this.floors[i] = floors[i];
		}
	}
	
	public int getCountFloors()		//общее количество этажей дома
	{
		return floors.length;
	}
	
	public int getAllFlatsCount()   // общее количество квартир дома
	{
		int c = 0;
		for(int i=0; i<floors.length; i++)
		{
			c+=floors[i].getCount();
		}
		return c;
	}
	
	public float getAllFlatsSpace() // общая площадь квартир дома
	{
		float c = 0;
		for(int i=0; i<floors.length; i++)
		{
			c+=floors[i].getSpace();
		}
		return c;
	}
	
	public int getAllRooms()  	//общее количество комнат дома
	{
		int c = 0;
		for(int i=0; i<floors.length; i++)
		{
			c+=floors[i].getCntRooms();
		}
		return c;
	}
	
	public DwellingFloor[] getFloors()  //получение массива этажей дома
	{
		return floors;
	}
	
	public DwellingFloor getFloor(int n)   //получение объекта этажа по номеру в доме 
	{
		return floors[n];
	}
	
	public void setFloor (int n, DwellingFloor floor)  //изменение этажа по номеру в доме
	{
		this.floors[n] = floor;
	}
	
	public Flat getGlobalFlat(int n)    //получение объекта квартиры по номеру в доме
	{
		int d = 0;
		for(int i=0; i<floors.length; i++)
		{
			for(int j=0; j<floors[i].getCntRooms(); j++)
			{
				if (n==(d+j))
				{
					return floors[i].getFlat(j);
				}

			}
			d+=floors[i].getCntRooms();
		}
		return null;
	
	}
	
	public void setGlobalFlat(int n, Flat flat)  		//метод изменения объекта квартиры по ее номеру в доме и ссылке типа квартиры
	{
		int d = 0;
		for(int i=0; i<floors.length; i++)
		{
			for(int j=0; j<floors[i].getCntRooms(); j++)
			{
				if (n==(d+j))
				{
					flat = floors[i].getFlat(j);
				}
			}
			d+=floors[i].getCntRooms();
		}
	
	}
	
	public void addFlatGlobal (int n, Flat flat) 		//добавление квартиры по будущему номеру и ссылке на квартиру
	{	
		int d = 0;
		for(int i=0; i<floors.length; i++)
		{
			for(int j=0; j<floors[i].getCntRooms(); j++)
			{
				if (n==(d+j))
				{
					this.floors[i].addFlat(j, flat);
				}

			}
			d+=floors[i].getCntRooms();
		}
	}

	public void delFlatGlobal (int n)   //удалелние квартиры по номеру в доме
	{	
		int d = 0;
		for(int i=0; i<floors.length; i++)
		{
			for(int j=0; j<floors[i].getCntRooms(); j++)
			{
				if (n==(d+j))
				{
					this.floors[i].delFlat(j);
				}

			}
			d+=floors[i].getCntRooms();
		}
	}
	
	public Flat getBestSpace()					//самая большая площадь по всему дому
	{
		Flat max = floors[0].getBestSpace();
		for(int i = 1; i<floors.length; i++)
		{
			if(max.getSpace()<floors[i].getBestSpace().getSpace())
				max = floors[i].getBestSpace();
		}
		return max;
	}
	
	public Flat[] getSortFlat()
	{
		Flat tmp[] = new Flat[this.getAllFlatsCount()];
		for(int i =0; i<tmp.length; i++)
		{
			tmp[i] = this.getGlobalFlat(i);
		}
		for(int i=0; i<tmp.length; i++)
			for(int j=0; j<tmp.length-1; j++)
			{
				if(tmp[j].getSpace()<tmp[j+1].getSpace())
				{
					Flat tmp_f = tmp[j];
					tmp[j] = tmp[j+1];
					tmp[j+1] = tmp_f;
				}
				
			}
		return tmp;	
	}
	
		
	
	
	
	
	
}