package buildings;



public class DwellingFloor {

        private Flat flats[];

        public DwellingFloor(int count)
        {
            flats = new Flat[count];
            for(int i=0; i<count; i++)
            {
                flats[i] = new Flat();
            }
        }

        public DwellingFloor(Flat[] flats)
        {
            this.flats = new Flat[flats.length];
            for(int i=0; i<flats.length; i++)
            {
                this.flats[i]=flats[i];
            }
        }

        public int getCount()                  //количество квартир на этаже
        {
            return flats.length;
        }

        public float getSpace()					//общая площадь квартир этажа
        {
            float c = 0;
            for (int i=0; i<flats.length; i++)
            {
                c+=flats[i].getSpace();
            }
            return c;
        }

        public int getCntRooms()				//общее количество комнат этажа
        {
            int c = flats[0].getRooms();
            for (int i=1; i<flats.length; i++)
            {
                c+=flats[i].getRooms();
            }
            return c;
        }

        public Flat[] getFlats()				//метод получения массива квартир этажа
        {
            return flats;
        }

        public Flat getFlat(int n)				//метод получения объекта квартиры по номеру на этаже
        {
            return flats[n];
        }

        public void setFlat(int n, Flat flat)		//метод изменения квартиры по ее номеру на этаже
        {
            this.flats[n] = flat;
        }

        public void addFlat(int n, Flat flat)		//добавление новой  квартиры на этаже
        {
            if(n>flats.length) {
                Flat tmp[]= new Flat[n];
                for(int i=0; i<flats.length; i++)
                {
                    tmp[i] = new Flat();
                }
                for(int i=0; i<flats.length; i++)
                {
                    tmp[i] = flats[i];
                }
                tmp[n-1] = flat;
                flats = tmp;
            }
            else
            {
                Flat tmp[]= new Flat[flats.length + 1];
                if(n == 0) {
                    tmp[n] = flat;
                    for (int i = 0; i < flats.length; i++) {
                        tmp[i+1] = flats[i];
                    }
                }
                else {
                    for (int i = 0; i < n; i++) {
                        tmp[i] = flats[i];
                    }
                    tmp[n] = flat;
                    for (int i = n + 1; i < tmp.length; i++) {
                        tmp[i] = flats[i];
                    }
                }
                flats = tmp;
            }
        }

        public void delFlat(int n)			//удаление квартиры по номеру на этаже
        {
            Flat tmp[] = new Flat[flats.length - 1];
            if(n==0)
            {
                for(int i = 0; i<flats.length-1; i++)
                {
                    tmp[i]= flats[i+1];
                }
            }
            else
            {
                for(int i = 0; i < n; i++) {
                    tmp[i] = flats[i];
                }
                for(int i = n; i < tmp.length; i++) {
                    tmp[i] = flats[i+1];
                }
            }
            flats = tmp;
        }

        public Flat getBestSpace()			//наибольшая кватира по площади на этаже
        {
            Flat max = flats[0];
            for (int i = 1; i<flats.length; i++)
            {
                if (max.getSpace() < flats[i].getSpace())
                    max = flats[i];
            }
            return max;
        }
}

